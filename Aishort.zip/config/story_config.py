"""
==================================================
Story Configuration
==================================================
"""

#
# Story Builder
#

MIN_SEGMENTS = 2

MAX_SEGMENTS = 12

#
# Story Size
#

MIN_WORDS = 20

MAX_WORDS = 500

#
# Ranking Weight
#

HOOK_WEIGHT = 0.30

CONFLICT_WEIGHT = 0.30

ENDING_WEIGHT = 0.20

ENGAGEMENT_WEIGHT = 0.20

#
# Score
#

MIN_SCORE = 0.0

MAX_SCORE = 100.0