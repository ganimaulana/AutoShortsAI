"""
==================================================
Subtitle Configuration
==================================================
"""

#
# Font
#

FONT_NAME = "Arial"

FONT_SIZE = 56

FONT_BOLD = True

#
# Layout
#

BOTTOM_MARGIN = 80

MAX_LINES = 2

MAX_WORDS_PER_LINE = 5

#
# Style
#

OUTLINE = 3

SHADOW = 0

ALIGNMENT = 2

PRIMARY_COLOR = "&H00FFFFFF"

OUTLINE_COLOR = "&H00000000"

BACK_COLOR = "&H64000000"