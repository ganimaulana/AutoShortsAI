"""
==================================================
Whisper Configuration
==================================================
"""

#
# Model
#

MODEL = "large-v3"

#
# Device
#

DEVICE = "cuda"

COMPUTE_TYPE = "float16"

#
# Decoding
#

BEAM_SIZE = 5

BEST_OF = 5

TEMPERATURE = 0.0

#
# Output
#

WORD_TIMESTAMPS = True

VAD_FILTER = True