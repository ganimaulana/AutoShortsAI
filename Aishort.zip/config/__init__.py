"""
==================================================
Gani Creative Studio
Powered by Naraseta

AutoShortsAI

Configuration Package
==================================================
"""