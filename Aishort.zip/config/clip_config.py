"""
==================================================
Clip Configuration
==================================================
"""

#
# Clip Count
#

MAX_CLIPS = 10

#
# Duration (seconds)
#

MIN_DURATION = 20.0

TARGET_DURATION = 40.0

MAX_DURATION = 60.0

#
# Timeline Padding
#

PRE_ROLL = 1.0

POST_ROLL = 1.0

#
# Export
#

EXPORT_FORMAT = "mp4"

VIDEO_CODEC = "libx264"

AUDIO_CODEC = "aac"

CRF = 18

PRESET = "medium"

FPS = 30