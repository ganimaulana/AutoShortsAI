"""
==================================================
Pipeline Configuration
==================================================
"""

#
# Pipeline Stage
#

ENABLE_ANALYZER = True

ENABLE_DOWNLOAD = True

ENABLE_TRANSCRIBER = True

ENABLE_STORY_BUILDER = True

ENABLE_STORY_RANKER = True

ENABLE_TIMELINE = True

ENABLE_CLIP_ENGINE = True

ENABLE_SUBTITLE = True

#
# Project
#

AUTO_CREATE_PROJECT = True

SAVE_METADATA = True